import { Store } from 'vuex'

declare const store: Store<{
  count: number
}>

export default store